INSERT INTO users (nome_completo, email, telefone, data_nascimento, endereco, cidade, cep, senha_hash)
VALUES
('Maria Silva', 'maria.silva@example.com', '11987654321', '1990-05-15', 'Rua das Flores, 123', 'São Paulo', '01234-567', 'hash_da_senha_maria'),
('João Santos', 'joao.santos@example.com', '21998765432', '1988-11-22', 'Avenida Principal, 456', 'Rio de Janeiro', '23456-789', 'hash_da_senha_joao'),
('Ana Oliveira', 'ana.oliveira@example.com', '31976543210', '1995-03-01', 'Travessa da Paz, 78', 'Belo Horizonte', '34567-890', 'hash_da_senha_ana');
