# Sistema de Cadastro SQL

Este documento fornece os scripts SQL para criar uma tabela de usuários e inserir dados de exemplo, que podem ser utilizados como base para um sistema de cadastro.

## 1. Estrutura do Banco de Dados

O esquema do banco de dados foi projetado para armazenar informações essenciais de usuários, incluindo dados pessoais e credenciais de acesso. A tabela principal é `users`.

### Tabela `users`

A tabela `users` contém os seguintes campos:

| Campo             | Tipo de Dados      | Restrições          | Descrição                                    |
|-------------------|--------------------|---------------------|----------------------------------------------|
| `id`              | `INT`              | `AUTO_INCREMENT`, `PRIMARY KEY` | Identificador único para cada usuário.       |
| `nome_completo`   | `VARCHAR(255)`     | `NOT NULL`          | Nome completo do usuário.                    |
| `email`           | `VARCHAR(255)`     | `NOT NULL`, `UNIQUE`| Endereço de e-mail do usuário (único).       |
| `telefone`        | `VARCHAR(20)`      |                     | Número de telefone do usuário.               |
| `data_nascimento` | `DATE`             |                     | Data de nascimento do usuário.               |
| `endereco`        | `VARCHAR(255)`     |                     | Endereço completo do usuário.                |
| `cidade`          | `VARCHAR(100)`     |                     | Cidade do usuário.                           |
| `cep`             | `VARCHAR(10)`      |                     | Código de Endereçamento Postal do usuário.   |
| `senha_hash`      | `VARCHAR(255)`     | `NOT NULL`          | Hash da senha do usuário (para segurança).   |
| `data_cadastro`   | `TIMESTAMP`        | `DEFAULT CURRENT_TIMESTAMP` | Data e hora do cadastro do usuário.          |

## 2. Scripts SQL Fornecidos

Dois scripts SQL foram gerados:

*   `create_users_table.sql`: Contém a instrução `CREATE TABLE` para criar a tabela `users`.
*   `insert_sample_users.sql`: Contém instruções `INSERT INTO` para popular a tabela `users` com alguns dados de exemplo.

## 3. Como Utilizar os Scripts

Para configurar o banco de dados e inserir os dados de exemplo, siga os passos abaixo:

1.  **Conecte-se ao seu servidor de banco de dados:** Utilize uma ferramenta de linha de comando (como `mysql` ou `psql`) ou uma interface gráfica (como phpMyAdmin, MySQL Workbench, DBeaver) para se conectar ao seu servidor de banco de dados (por exemplo, MySQL, PostgreSQL, SQL Server).

2.  **Crie um banco de dados (se ainda não tiver um):**

    ```sql
    CREATE DATABASE nome_do_seu_banco_de_dados;
    USE nome_do_seu_banco_de_dados;
    ```

    Substitua `nome_do_seu_banco_de_dados` pelo nome que você deseja dar ao seu banco de dados.

3.  **Execute o script de criação da tabela:**

    Abra o arquivo `create_users_table.sql` e execute seu conteúdo no seu cliente SQL. Isso criará a tabela `users`.

    Exemplo via linha de comando (MySQL):
    ```bash
    mysql -u seu_usuario -p nome_do_seu_banco_de_dados < create_users_table.sql
    ```

4.  **Execute o script de inserção de dados de exemplo (opcional):**

    Abra o arquivo `insert_sample_users.sql` e execute seu conteúdo. Isso adicionará três usuários de exemplo à sua tabela `users`.

    Exemplo via linha de comando (MySQL):
    ```bash
    mysql -u seu_usuario -p nome_do_seu_banco_de_dados < insert_sample_users.sql
    ```

## 4. Considerações de Segurança

*   **Hash de Senhas:** O campo `senha_hash` é destinado a armazenar senhas de forma segura, utilizando funções de hash (ex: bcrypt, Argon2). **Nunca armazene senhas em texto puro.** Certifique-se de implementar um algoritmo de hash robusto em sua aplicação ao registrar novos usuários.
*   **Validação de Entrada:** Sempre valide e sanitize todas as entradas do usuário em sua aplicação para prevenir ataques como Injeção SQL.

Com esses scripts, você terá a base de dados pronta para integrar com sua aplicação de cadastro.
